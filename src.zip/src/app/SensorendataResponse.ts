export interface SensorendataResponse {
    id: number;
    date: Date;
    temperature: number,
    humidity: number
    sensorId: number
  }